
function [t_final,s_final,d_final,obj_final,flag] = Test_not_appending_0(J,L,T,S,D,CU,CD,CC,V,...
    CTU,CTD,Qt,M,Bp,t_temp,s_temp,d_temp)

M = min(M);
P=(Bp)'*J;
LL=L*ones(9,1);

% jj = 1;
% for ii = 1:length(d_temp)
% if d_temp(ii)<= 4
% d_new(jj) = d_temp(ii);
% jj = jj+1;
% end
% end
% clear d_new;
d_new = d_temp;

obj_record = 0;
num = 1;
for i= 1:length(t_temp)

  for j= 1:length(s_temp)

     for k= 1:length(d_new)
         
t= t_temp(i);
s= s_temp(j);
d= d_new(k);
x=T/t_temp(i);
y=S/s_temp(j);
z=D/d_new(k);
obj=(  CU*J*(x*y+y*z)+CD*J*(x*z)+CC*J*(x*y*z)  );
Cons=  P/s-LL ; 
Cons(10:11,1) = [ (L*(s*d+2*s)+t*s*d+t*s-1-sum(J)) ; ...
     (x*y+y*z+x*z-M) ];
for a=1:11
Cons(11+a,1) = ...
J(a)/V(a)*(x*y*z)+J(a)/CTU(a)*(x*y+y*z)+J(a)/CTD(a)*(x*z) - Qt;
end

if Cons <= 0
t_record(num,1) = t_temp(i);
s_record(num,1) = s_temp(j);
d_record(num,1) = d_new(k);
obj_record(num,1) = obj;
num = num+1;
end

     end
  end
end

[obj_final,index]=min(obj_record);
if obj_record == 0
    flag = 0;
    t_final = 0;
    s_final = 0;
    d_final = 0;
    obj_final = 0;
else
    flag = 1;
    t_final = t_record(index,1);
    s_final = s_record(index,1);
    d_final = d_record(index,1);
end

end
%%
% intvar t s d
% 
% M = min(M);
% P=(Bp)'*J;
% LL=L*ones(9,1);
% 
% %%
% % objective=(  CU*J*(x*y+y*z)+CD*J*(x*z)+CC*J*(x*y*z)  )/1e13;
% % Constraints= [ P/s-LL <=0, L*(s*d+2*s)+t*s*d+t*s-1-sum(J) <= 0, ...
% %     x*y+y*z+x*z <= M];
% % for a=1:11
% % Constraints = [Constraints, ...
% % J(a)/V(a)*(x*y*z)+J(a)/CTU(a)*(x*y+y*z)+J(a)/CTD(a)*(x*z) <= Qt];
% % end
% % Constraints= [Constraints, 1 <= t <= T, 1 <= s, 1 <= d <= D, d <= 4, ...
% %     x*t == T, y*s == S, z*d == D,...
% %     1 <= x <= T, 1 <= y <= S, 1 <= z <= D];
% 
% %%
% objective=( CU*J*( T*S/(t*s)+ S*D/(s*d) ) ...
%     +CD*J*(T*D/(t*d) )+CC*J*( T*S*D/(t*s*d ) ) );
% Constraints= [ P/s-LL <=0, L*(s*d+2*s)+t*s*d+t*s-1-sum(J) <= 0, ...
%     T*S/(t*s)+S*D/(s*d)+T*D/(t*d) <= M];
% for a=1:11
% Constraints = [Constraints, ...
% J(a)/V(a)*( T*S*D/(t*s*d) )...
% +J(a)/CTU(a)*( T*S/(t*s)+S*D/(s*d) )...
% +J(a)/CTD(a)*( T*D/(t*d) ) <= Qt];
% end
% 
% Constraints= [Constraints, 1 <= t <= T, 1 <= s,...
%     1 <= d <= D, d <= 4 ];
% 
% optimize(Constraints,objective)
% 
% t=double(t);
% s=double(s);
% d=double(d);
% % x=round(t);
% % y=round(s);
% % z=round(d);
% 
% for aa = 1:11
% time(aa) = J(a)/V(a)*(x*y*z)+J(a)/CTU(a)*(x*y+y*z)...
%     +J(a)/CTD(a)*(x*z);
%     if  time(aa)<= Qt
%         index(aa) = 1;
%     else
%         index(aa) = 0;
%     end
% end
% storage=x*y+y*z+x*z;
% if storage <= M
%     index(length(index)+1) = 1;
% else
%     index(length(index)+1) = 0;
% end
% 
% flag=all(index);
% obj = CU*J*(x*y+y*z)+CD*J*(x*z)+CC*J*(x*y*z) ;


% end
