function [v] = find_factor(x)
k=1;
for i=1:x
	if mod(x,i)==0
        factors(k)=i;
		k=k+1;
	end
end
v = factors;

end