
function [t,s,d,x,y,z,flag] = Test_appending_0(J,L,T,S,D,CU,CD,CC,V,CTU,CTD,Qt,M,Bp)

intvar t s d x y z

M = min(M);
P=(Bp)'*J;
LL=L*ones(9,1);

%%
% objective=(  CU*J*(x*y+y*z)+CD*J*(x*z)+CC*J*(x*y*z)  )/1e13;
% Constraints= [ P/s-LL <=0, L*(s*d+2*s)+t*s*d+t*s-1-sum(J) <= 0, ...
%     x*y+y*z+x*z <= M];
% for a=1:11
% Constraints = [Constraints, ...
% J(a)/V(a)*(x*y*z)+J(a)/CTU(a)*(x*y+y*z)+J(a)/CTD(a)*(x*z) <= Qt];
% end
% Constraints= [Constraints, 1 <= t <= T, 1 <= s, 1 <= d <= D, d <= 4, ...
%     x*t == T, y*s == S, z*d == D,...
%     1 <= x <= T, 1 <= y <= S, 1 <= z <= D];

%%
objective=( CU*J*( T*S/(t*s)+ S*D/(s*d) ) ...
    +CD*J*(T*D/(t*d) )+CC*J*( T*S*D/(t*s*d ) ) );
Constraints= [ P/s-LL <=0, L*(s*d+2*s)+t*s*d+t*s-1-sum(J) <= 0, ...
    T*S/(t*s)+S*D/(s*d)+T*D/(t*d) <= M];
for a=1:11
Constraints = [Constraints, ...
J(a)/V(a)*( T*S*D/(t*s*d) )...
+J(a)/CTU(a)*( T*S/(t*s)+S*D/(s*d) )...
+J(a)/CTD(a)*( T*D/(t*d) ) <= Qt];
end

% Constraints= [Constraints, 1 <= t <= T, 1 <= s,...
%     1 <= d <= D, d <= 4 ];    %% Bp1

Constraints= [Constraints, 1 <= t <= T, 1 <= s,...
    1 <= d <= D, d <= 6 ];   %% Bp2

optimize(Constraints,objective)

t=double(t);
s=double(s);
d=double(d);
x = ceil(T/t);
y = ceil(S/s);
z = ceil(D/d);
% x=double(x);
% y=double(y);
% z=double(z);

for aa = 1:11
time(aa) = J(aa)/V(aa)*(x*y*z)+J(aa)/CTU(aa)*(x*y+y*z)...
    +J(aa)/CTD(aa)*(x*z);
    if  time(aa)<= Qt
        index(aa) = 1;
    else
        index(aa) = 0;
    end
end
storage=x*y+y*z+x*z;
if storage <= M
    index(length(index)+1) = 1;
else
    index(length(index)+1) = 0;
end

flag=all(index);
obj = CU*J*(x*y+y*z)+CD*J*(x*z)+CC*J*(x*y*z) ;


end
