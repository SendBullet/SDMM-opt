function [J,L,flag] = LP_new(t,s,d,T,S,D,CU,CD,CC,V,CTU,CTD,Qt,M,Bp)
% x_one=ones(9,1);
% n=11;    %% Bp1

x_one=ones(9,1);
n=20;    %% Bp2

x = ceil(T/t);
y = ceil(S/s);
z = ceil(D/d);

% cvx_begin
% variable JJ(11)
% variable LL
% 
% minimize( (CU*JJ*(x*y+y*z)+CD*JJ*(x*z)+CC*JJ*(x*y*z)) )
% subject to
% 
% (Bp)'*JJ-(LL*s)*x_one <= 0 ;
% LL*(s*d+2*s)+t*s*d+t*s-1-sum(JJ) == 0 ;
% 
% LL >= 1;
% for k=1:11
% %    JJ(k)-LL*s <= 0;
%    -JJ(k) <= 0 ;
%    JJ(k)/V(k)*(x*y*z)+JJ(k)/CTU(k)*(x*y+y*z)+JJ(k)/CTD(k)*(x*z) <= Qt ;  
% end
% 
% 
% cvx_end


% if length(cvx_status) == 6
L=optimvar('L','LowerBound',1,'Type','integer');
J=optimvar('J',n,'LowerBound',0,'Type','integer');
prob = optimproblem('Objective', (CU*J*(x*y+y*z)+CD*J*(x*z)+CC*J*(x*y*z))  );
cons1 = (Bp)'*J-(L*s)*x_one <= 0;
cons2 = L*(s*d+2*s)+t*s*d+t*s-1-sum(J) == 0;
cons3 =  J.*(1./V')*(x*y*z)+J.*(1./CTU')*(x*y+y*z)+J.*(1./CTD')*(x*z) <= Qt*ones(n,1) ;
% cons4 = J <= L*s*ones(11,1);
cons5 = -J <= 0*ones(n,1);
cons6 = L >= 1;
prob.Constraints.cons1 = cons1;
prob.Constraints.cons2 = cons2;
prob.Constraints.cons3 = cons3;
% prob.Constraints.cons4 = cons4;
prob.Constraints.cons5 = cons5;
prob.Constraints.cons6 = cons6;
problem = prob2struct(prob);
[sol,fval,exitflag,output] = intlinprog(problem);
% else
% end
if exitflag == 1
flag = 1;
J=round(sol(1:n,1));
L = round(sol(n+1,1));
else
J=zeros(1:n,1);
L =0;
flag = 0;
end
end




