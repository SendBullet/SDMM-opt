clear;
clc;
clf;
%% homogenuous paramteter
% CU=4e-8*ones(1,11);
% CD=4e-8*ones(1,11);
% CC=6e-8*ones(1,11);
% 
% V=5e8*ones(1,11);
% CTU=2048e4*ones(1,11);
% CTD=2048e4*ones(1,11);
% 
% Qt=1e3;
% 
% M=2e6*ones(11,1);

%% server 11 heterogenous parameter
% CU=3e-8*ones(1,11);
% CU(1,5:8) = 4e-8*ones(1,4);
% CU(1,9:11) = 5e-8*ones(1,3);
% 
% CD=3e-8*ones(1,11);
% CD(1,5:8) = 4e-8*ones(1,4);
% CD(1,9:11) = 5e-8*ones(1,3);
% 
% CC=2e-8*ones(1,11);
% CC(1,5:8) = 6e-8*ones(1,4);
% CC(1,9:11) = 8e-8*ones(1,3);
% 
% V=2e8*ones(1,11);
% V(1,5:8) = 5e8*ones(1,4);
% V(1,9:11) = 8e8*ones(1,3);
% 
% CTU=1024e4*ones(1,11);
% CTU(1,5:8) = 2048e4*ones(1,4);
% CTU(1,9:11) = 4096e4*ones(1,3);
% 
% CTD=1024e4*ones(1,11);
% CTD(1,5:8) = 2048e4*ones(1,4);
% CTD(1,9:11) = 4096e4*ones(1,3);
% Qt=1e3;
% 
% M=1e6*ones(11,1);
% M(5:8,1) = 2e6*ones(4,1);
% M(9:11,1) = 3e6*ones(3,1);

% Bp=[1 0 1 0 0 0 0 0 0;
%     0 1 1 0 0 0 0 0 0;
%     0 0 0 1 0 0 0 0 0;
%     1 0 0 0 1 0 0 0 0;
%     0 1 0 0 1 0 0 0 0;
%     0 0 1 0 1 0 0 0 0;
%     0 0 0 1 1 0 0 0 0;
%     0 0 0 0 0 1 0 0 0;
%     0 0 0 0 0 0 1 0 0;
%     0 0 0 0 0 0 0 1 0;
%     0 0 0 0 0 0 0 0 1];%% N*M维矩阵

%% 20 servers
CU=3e-8*ones(1,20);
CU(1,8:15) = 4e-8*ones(1,8);
CU(1,16:20) = 5e-8*ones(1,5);

CD=3e-8*ones(1,20);
CD(1,8:15) = 4e-8*ones(1,8);
CD(1,16:20) = 5e-8*ones(1,5);

CC=2e-8*ones(1,20);
CC(1,8:15) = 6e-8*ones(1,8);
CC(1,16:20) = 8e-8*ones(1,5);

V=2e8*ones(1,20);
V(1,8:15) = 5e8*ones(1,8);
V(1,16:20) = 8e8*ones(1,5);

CTU=1024e4*ones(1,20);
CTU(1,8:15) = 2048e4*ones(1,8);
CTU(1,16:20) = 4096e4*ones(1,5);

CTD=1024e4*ones(1,20);
CTD(1,8:15) = 2048e4*ones(1,8);
CTD(1,16:20) = 4096e4*ones(1,5);
Qt=1e3;

M=1e6*ones(20,1);
M(8:15,1) = 2e6*ones(8,1);
M(16:20,1) = 3e6*ones(5,1);



Bp = zeros(20,9);
Bp(1:6,1) = ones(6,1);
Bp(6:11,2) = ones(6,1);
Bp(12:13,3) = ones(2,1);
Bp(14,4) = 1;
Bp(13,5) = 1;
Bp(15,5) = 1;
Bp(16:17,6) = ones(2,1);
Bp(18,7) = 1;
Bp(19,8) = 1;
Bp(20,9) = 1;

%% cost vs S
% D=2500;
% T=2500;
% 
% S_0 = 1000;
% for ii = 1:50
% [value,inner,t_ini,s_ini,d_ini,t_temp,s_temp,d_temp] = feasibility(T,S_0,D,CU,...
%     CD,CC,V,CTU,CTD,Qt,M,Bp);
% if inner == 1
%     t = t_ini;
%     s = s_ini;
%     d = d_ini;
%     break;
% end
% end
% 
% 
% flag=0;
% for gg=1:2
% S=1000;
% SS = linspace(1000,4000,7);
% for g=1:7

%% cost vs T
% D=2500;
% S=2500;
% 
% T_0 = 1000;
% for ii = 1:50
% [value,inner,t_ini,s_ini,d_ini,t_temp,s_temp,d_temp] = feasibility(T_0,S,D,CU,...
%     CD,CC,V,CTU,CTD,Qt,M,Bp);
% if inner == 1
%     t = t_ini;
%     s = s_ini;
%     d = d_ini;
%     break;
% end
% end
% 
% flag=0;
% for gg=1:2
% T=1000;
% TT=linspace(1000,4000,7);
% for g=1:7 

%% cost vs D 
T=2500;
S=2500;
D_0 = 1000;
for ii = 1:50
[value,inner,t_ini,s_ini,d_ini,t_temp,s_temp,d_temp] = feasibility(T,S,D_0,CU,...
    CD,CC,V,CTU,CTD,Qt,M,Bp);
if inner == 1
    t = t_ini;
    s = s_ini;
    d = d_ini;
    break;
end
end





flag=0;
for gg=1:2
D=1000;
DD=linspace(1000,4000,7);
for g=1:7
    
%% code   
% clear;
% clc;
% D=500;
% T=5000;
% S=5000;
% t=300;
% s=200;
% d=3;%%d < 5



times=10;
i=1;
% iteration=1;
while(i < times )  

%% proposed schemes
[J,L,inner]=LP_new(t,s,d,T,S,D,CU,CD,CC,V,CTU,CTD,Qt,M,Bp);
% [J,L]=LP_appending_0(t,s,d,T,S,D,CU,CD,CC,V,CTU,CTD,Qt,M,Bp);
[t,s,d,x,y,z,fea_flag]=Test_appending_0(J,L,T,S,D,CU,CD,CC,V,CTU,CTD,Qt,M,Bp);
% x = ceil(T/t);
% y = ceil(S/s);
% z = ceil(D/d);
obj(i)=CU*J*(x*y+y*z)+CD*J*(x*z)+CC*J*(x*y*z) ;

if i >= 2
error(i-1)=abs((obj(i)-obj(i-1)))/obj(i-1);
if  error > 10^(-8)
    inner_flag = 0;
else
    value=obj(length(obj));
    inner_flag = 1;
    break;
end
end
i = i+1;
end

clear obj error;
L_all(gg,g) = L;
fea_flag_all(gg,g) = fea_flag;

%% not appending 0, no optimization
[J_no,L_no,inner_no]=LP_new(t_ini,s_ini,d_ini,T,S,D,...
    CU,CD,CC,V,CTU,CTD,Qt,M,Bp);

if inner_no == 1
x_no = T/t_ini;
y_no = S/s_ini;
z_no = D/d_ini;
value_no=CU*J_no*(x_no*y_no+y_no*z_no)...
    +CD*J_no*(x_no*z_no)+CC*J_no*(x_no*y_no*z_no) ;
else
    value_no = 0;
end
 
L_all_no(gg,g) = L_no;

%% not appending 0, optimization 
ii=1;
while(ii < times )  
[J_ii,L_ii,inner_ii]=LP_new(t_ini,s_ini,d_ini,T,S,D,...
    CU,CD,CC,V,CTU,CTD,Qt,M,Bp);
[t_ii,s_ii,d_ii,obj_ii,fea_flag_ii]...
=Test_not_appending_0(J_ii,L_ii,T,S,D,CU,CD,CC,V,CTU,CTD,...
Qt,M,Bp,t_temp,s_temp,d_temp);
if fea_flag_ii == 1
obj_not(ii) = obj_ii;
  if ii >= 2
  error_ii(ii-1)=abs((obj_not(ii)-obj_not(ii-1)))/obj_not(ii-1);
    if  error_ii > 10^(-8)
    inner_flag_ii = 0;
    else
    value_ii=obj_not(length(obj_not));
    inner_flag_ii = 1;
    break;
    end
  end

else
value_ii = value_no;
end

ii = ii+1;
end

clear obj_not error_ii;

%% hua tu cost vs S
% color(g)=value;
% color_no(g) = value_no;
% color_ii(g) = value_ii;
% S=S+500;
% 
% end
% if flag == 0
% plot(SS,color,'ro-','linewidth',1.5);
% hold on
% plot(SS,color_no,'g>-','linewidth',1.5);
% hold on
% plot(SS,color_ii,'b*--','linewidth',1.5);
% TD2500 = color;
% not0_TD2500 = color_no;
% not0_opt_TD2500 = color_ii;
% 
% 
% hold on;
% elseif flag == 1
% plot(SS,color,'rh-','linewidth',1.5);
% hold on
% plot(SS,color_no,'g<-','linewidth',1.5);
% hold on
% plot(SS,color_ii,'bd--','linewidth',1.5);
% TD3500 = color;
% not0_TD3500 = color_no;
% not0_opt_TD3500 = color_ii;
% 
% 
% % legend('T=2500,D=2500','T=3500,D=3500');
%  legend('Pro., T=2500,D=2500','SE., T=2500,D=2500','N/0., T=2500,D=2500',...
%     'Pro., T=3500,D=3500','SE., T=3500,D=3500','N/0., T=3500,D=3500');
% hold on;
% xlabel('S (rows)');
% ylabel('Total Cost')
% grid on
% end
% 
% T=T+1000;
% D=D+1000;
% flag=flag+1;
% end

%% cost vs T
% color(g)=value;
% color_no(g) = value_no;
% color_ii(g) = value_ii;
% T=T+500;
% end
% if flag == 0
% plot(TT,color,'ro-','linewidth',1.5);
% hold on
% plot(TT,color_no,'g>-','linewidth',1.5);
% hold on
% plot(TT,color_ii,'b*--','linewidth',1.5);
% SD2500 = color;
% not0_SD2500 = color_no;
% not0_opt_SD2500 = color_ii;
% 
% % SD2500 = color;
% 
% hold on;
% elseif flag == 1
% plot(TT,color,'rh-','linewidth',1.5);
% hold on
% plot(TT,color_no,'g<-','linewidth',1.5);
% hold on
% plot(TT,color_ii,'bd--','linewidth',1.5);
% SD3500 = color;
% not0_SD3500 = color_no;
% not0_opt_SD3500 = color_ii;
% % SD3500 = color;
% % 
% 
% legend('Pro., S=2500,D=2500','SE., S=2500,D=2500','N/0., S=2500,D=2500',...
%     'Pro., S=3500,D=3500','SE., S=3500,D=3500','N/0., S=3500,D=3500');
% % legend('S=2500,D=2500','S=3500,D=3500');
% xlabel('T (rows)');
% ylabel('Total Cost')
% grid on
% end
% 
% S=S+1000;
% D=D+1000;
% flag=flag+1;
% end


%% cost vs D
color(g)=value;
color_no(g) = value_no;
color_ii(g) = value_ii;
D=D+500;
end
if flag == 0
plot(DD,color,'ro-','linewidth',1.5);
hold on
plot(DD,color_no,'g>-','linewidth',1.5);
hold on
plot(DD,color_ii,'b*--','linewidth',1.5);
TS2500 = color;
not0_TS2500 = color_no;
not0_opt_TS2500 = color_ii;

hold on;
elseif flag == 1
plot(DD,color,'rh-','linewidth',1.5);
hold on
plot(DD,color_no,'g<-','linewidth',1.5);
hold on
plot(DD,color_ii,'bd--','linewidth',1.5);
TS3500 = color;
not0_TS3500 = color_no;
not0_opt_TS3500 = color_ii;

legend('Pro., T=2500,S=2500','SE., T=2500,S=2500','N/0., T=2500,S=2500',...
    'Pro., T=3500,S=3500','SE., T=3500,S=3500','N/0., T=3500,S=3500');
% legend('Ho. T=2500,S=2500','Ho. T=3500,S=3500','He. T=2500, S=2500','He. T=3500, S=3500')
xlabel('D (columns)');
ylabel('Total Cost')
grid on
end

S=S+1000;
T=T+1000;
flag=flag+1;
end
