function [value,inner,t,s,d,t_temp,s_temp,d_temp] = feasibility(T,S,D,CU,...
    CD,CC,V,CTU,CTD,Qt,M,Bp)

[t_temp]=find_factor(T);
[s_temp]=find_factor(S);
[d_temp]=find_factor(D);
t = t_temp(randperm(length(t_temp),1));
s = s_temp(randperm(length(s_temp),1));

jj = 1;
for ii = 1:length(d_temp)
% if d_temp(ii)<= 4  %% Bp1
if d_temp(ii)<= 6  %% Bp2
d_new(jj) = d_temp(ii);
jj = jj+1;
end
end
d = d_new(randperm(length(d_new),1));

% d = d_temp(randperm(length(d_temp),1));


[J,L,inner]=LP_new(t,s,d,T,S,D,CU,CD,CC,V,CTU,CTD,Qt,M,Bp);

if inner == 1
    x = T/t;
    y = S/s;
    z = D/d;
    value=CU*J*(x*y+y*z)+CD*J*(x*z)+CC*J*(x*y*z) ;
else
    value  = 0;
end

end